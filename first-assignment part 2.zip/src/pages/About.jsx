import './About.css'

export default function About(){
    return (
      <>
      <h1>About</h1>
      <div className="about-page">
        <div className='about'>
            <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque faucibus porttitor leo, ut viverra tellus aliquet id. Aenean quis justo maximus sem pulvinar facilisis quis at orci. Sed vel est libero. Donec elementum aliquet odio a vestibulum. Mauris aliquam in diam sed cursus. Donec sit amet tortor vel erat pretium consectetur fermentum ac quam. Etiam sed mauris pretium massa imperdiet vulputate aliquam at nunc. In eu lectus placerat, faucibus diam eu, auctor metus.
            </p>
            <p>
            Donec eu elementum risus. Aliquam convallis, est et sagittis porttitor, felis lectus laoreet lectus, ut rhoncus ipsum nisl vel mauris. Suspendisse dapibus, enim et efficitur fermentum, mi lacus fermentum orci, ut pulvinar diam dui eget dolor. Nunc ultricies purus efficitur libero tristique, sed sollicitudin felis vestibulum. Etiam mattis ac tortor nec convallis. Nunc facilisis dui et justo ultricies accumsan. Nunc nec lectus non dolor luctus laoreet. Integer eu venenatis nibh. In hac habitasse platea dictumst.
            </p>
            <p>
            Nam gravida, dui id luctus ullamcorper, ante erat fermentum urna, ut lobortis justo magna vel nisl. Curabitur risus felis, vehicula quis dui vel, ornare porttitor risus. Nam semper imperdiet erat vel efficitur. Curabitur non elit ut eros fermentum lacinia. Vestibulum congue dapibus blandit. Phasellus venenatis vulputate diam quis sagittis. Nunc id vulputate tellus. Suspendisse at efficitur lorem. Donec tincidunt bibendum enim, in mollis lorem blandit ac. Phasellus porta quam vel ligula feugiat, sit amet volutpat lorem aliquam. Sed et mauris eu nisi vehicula consectetur eget sit amet risus. Phasellus efficitur ante sapien, sit amet rutrum risus blandit vel. Sed quis pulvinar ex. Aliquam scelerisque sapien consequat venenatis aliquam. Quisque varius varius sollicitudin.
            </p>
            <p>
            Nunc dictum quam sed est pretium dapibus. Phasellus tempor justo ut viverra venenatis. In porta at velit sit amet venenatis. Maecenas quis eros ullamcorper, tempus lectus in, scelerisque sem. Etiam placerat luctus turpis eget lobortis. Phasellus semper justo sit amet diam vehicula, quis efficitur velit imperdiet. Morbi ullamcorper tortor neque, a facilisis est varius quis. Nullam interdum purus quis turpis rhoncus, quis lacinia nibh eleifend. Aliquam consectetur elit justo, quis efficitur dui laoreet nec. Aenean id velit varius, maximus tortor vitae, mattis ligula. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.
            </p>
        </div>
        </div>
      </>
    )
}